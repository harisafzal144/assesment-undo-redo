# reactjs assesment

Please download, run `npm install`, and verify that `npm start` works as expected.