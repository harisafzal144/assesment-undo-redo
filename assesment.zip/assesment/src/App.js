import React, { useState , useEffect} from "react";
import { getUsers, createUser, createUserWithId, removeUser } from "./ApiService";
import "./styles.css";

const CreateUserForm = ({ create }) => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");

  const resetForm = () => {
    setFirstName("");
    setLastName("");
    setEmail("");
  };

  return (
    <form
      onSubmit={(createUserEvent) => {
        createUserEvent.preventDefault();

        // implementation required.
        create({ firstName, lastName, email });
        //create(createUserEvent)

        resetForm();
      }}
    >
    <div>
        <input
            
            className="input-text input-text--firstName"
            name="firstName"
            placeholder="First"
            value={firstName}
            required
            onChange={(event) => setFirstName(event.target.value)}
          />
          <input
            className="input-text input-text--lastName"
            name="lastName"
            placeholder="Last"
            value={lastName}
            required
            onChange={(event) => setLastName(event.target.value)}
          />

    </div>
     <div>
      <input
          className="input-text input-text--email"
          name="email"
          placeholder="Email"
          type="email"
          value={email}
          required
          onChange={(event) => setEmail(event.target.value)}
        />
     </div>
      <div >
       <input className="button input-text--addBtn" type="submit" value="Add User" />
      </div>
    </form>
  );
};

const ListUsers = ({ users, remove }) => (
  <div>
    <div className="userTitle">
      <h2>Users</h2>
    </div>
    <div >
    <ul className="user-list">
      {users.map((user) => (
        <div style={{display: 'flex', justifyContent: 'center'}}>
          <li className="user-detail" key={user.userId}>
          <span className="display-text">{user.firstName}</span>
          <span className="display-text">{user.lastName}</span>
          <span className="display-text">{user.email}</span>
          <button style={{border: 'none', background: 'transparent', cursor: 'pointer'}} onClick={() => remove({...user,remove:true})}>X</button>
          </li>
        </div>
      ))}
    </ul>

    </div>
  </div>
);

const Footer = ({ undo, redo }) => (
  <div className="footer">
    <button className="undoBtn" onClick={undo}>Undo</button>
    <button className="redoBtn" onClick={redo}>Redo</button>
  </div>
);

export default function App() {
  // states
  const [users, setUsers] = useState([]);
  //for undo and redo 
  const [bossArray, setBossArray] = useState([]);
  const [change, setChnage] =useState(false);


  useEffect(() => {
    if(change === true){
      updateList();
      setChnage(false);
    }

  }, [change]);


  // functions
  const updateList = () => {
    const allUsers = getUsers();
    var newthing = [];
    console.log(allUsers, "allUsers");
    allUsers.map((user,i) => {
      var thingtoAdd = {};
    
      thingtoAdd.userId = user?.userId?.toString().slice(-5) || user?.firstName?.userId?.toString().slice(-5);
      thingtoAdd.firstName = user.firstName.firstName;
      thingtoAdd.lastName = user.firstName.lastName;
      thingtoAdd.email = user.firstName.email;
      newthing.push(thingtoAdd);
    });
    console.log(newthing, "newthing");
    setUsers(newthing);
  }

  // handlers 
  const create = (user) => {
    // implementation required.
    
    const obj = {
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email
    }
    const createdUser = createUser({firstName: user.firstName, lastName: user.lastName, email: user.email});
    obj.userId = createdUser.userId;
    console.log(obj, "obj");
   console.log(getUsers(), "allUsers");
   setChnage(true);
};
  const remove = (user) => {
    // implementation required.
    console.log(user, "user");
    removeUser("[object Object]undefinedundefined-"+user?.userId);
    setChnage(true);
    
   
  };

  const directRemove= (user) =>{
        setBossArray([...bossArray, user]);
        remove(user);
  }
  const undo = () => {
      
      
          if(bossArray[bossArray.length-1]?.remove === true){
            if(bossArray.length > 0){
              const  userId = bossArray[bossArray.length-1].userId;
              const firstName =bossArray[bossArray.length-1].firstName;
              const lastName =bossArray[bossArray.length-1].lastName;
              const email = bossArray[bossArray.length-1].email;
              // setBossArray([...bossArray.slice(0, bossArray[bossArray.length -1]) ]);
              createUser({firstName, lastName, email});
              let temp = bossArray;
              temp.pop();
              setBossArray(temp);
              setChnage(true);
            }
            else{
              console.log("no more undo");
            }

          }
          else if(users.length > 0){
            setBossArray([...bossArray, users[users?.length-1] ]);
            remove(users[users?.length-1]);
          }
          else{
            alert("no more undo");
          }
          

  };
  const redo = () => {
    console.log(bossArray, "bossArray");
    if(bossArray.length > 0){
      const  userId = bossArray[bossArray.length-1].userId;
      const firstName =bossArray[bossArray.length-1].firstName;
      const lastName =bossArray[bossArray.length-1].lastName;
      const email = bossArray[bossArray.length-1].email;
      createUser({firstName, lastName, email});
      let temp = bossArray;
      temp.pop();
      setBossArray(temp);
      setChnage(true);
    }
    else{
      alert("no more redo");
    }
  };

  return (
    <div className="App">
      <div className="container">
       <div className="title">
        <h1>Create User</h1>
       </div>
       <div className="formDiv">
         <CreateUserForm create={create} />
       </div>
       <div className="UserList">
         <ListUsers users={users} remove={directRemove} />
       </div>
       <div className="diff-line">
        <hr style={{width: '40%'}}/>
       </div>
       <div className="footerDiv">
        <Footer  undo={undo} redo={redo} />
       </div>

      </div>
      
    </div>
  );
}



